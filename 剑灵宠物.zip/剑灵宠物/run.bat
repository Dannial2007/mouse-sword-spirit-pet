@echo off
cd /d "%~dp0"

set "PY="
where python >nul 2>nul && set "PY=python"
if not defined PY (
  set "BUNDLED=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
  if exist "%BUNDLED%" set "PY=%BUNDLED%"
)
if not defined PY (
  echo [ERROR] Python not found. Install Python 3 with tcl/tk enabled.
  pause
  exit /b 1
)

echo Starting SwordPet (%PY%) ...
echo Close: right-click the pet - Quit.  Hide/Show: Ctrl+Alt+P
echo.
"%PY%" pet.py
if not "%errorlevel%"=="0" (
  echo.
  echo ==================================================
  echo Program exited with code %errorlevel%. Error above.
  echo ==================================================
  pause
)

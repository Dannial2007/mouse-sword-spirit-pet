@echo off
cd /d "%~dp0"

set "PY="
where python >nul 2>nul && set "PY=python"
if not defined PY (
  set "BUNDLED=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
  if exist "%BUNDLED%" set "PY=%BUNDLED%"
)
if not defined PY (
  echo [ERROR] Python not found.
  pause
  exit /b 1
)

echo Running diagnostic... two pet windows will show at screen center (~2.5s each).
"%PY%" pet.py --check
echo.
pause

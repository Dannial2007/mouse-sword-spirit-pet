# -*- coding: utf-8 -*-
"""
小剑灵 —— 鼠标宠物（bongo-cat 风格）

特性：
  * 透明、置顶、无边框窗口，只显示角色本身
  * 平时呆在鼠标周围，鼠标移动时用弹簧物理平滑跟随（有拖尾感）
  * 鼠标静止时播放呼吸/漂浮动画
  * 点击鼠标【任意位置】都会挥剑（GetAsyncKeyState 轮询检测全局点击）
  * 固定（钉住）后不再跟随，也不再播放飞行动画
  * 默认「鼠标穿透」：宠物不挡你的点击（点不到它）
  * 按住 Ctrl：宠物停住并临时可点击，方便拖拽/右键控制，松开恢复
  * 右键菜单：跟随 / 固定 / 大小 / 鼠标穿透 / 隐藏 / 退出
  * 鼠标滚轮在宠物上滚动 = 随时调整大小
  * 热键（轮询检测，稳定）：Ctrl+Alt+P 显隐、Ctrl+Alt+T 穿透、Ctrl+Alt+Q 退出
  * 位置、模式、大小、穿透状态自动保存到 config.json

运行（任选其一）：
    python pet.py
    run.bat

注意：请用普通方式启动（双击 run.bat 或命令行运行）。
如果在受限沙箱里启动，Windows 会拦截“全局鼠标钩子”，导致
“点击任意位置”检测不到（只能点到宠物本体才有反应）。
"""
import ctypes
import json
import math
import os
import sys
import tkinter as tk
from ctypes import wintypes

APP_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(APP_DIR, "assets")
CONFIG_PATH = os.path.join(APP_DIR, "config.json")

# ---- 可调参数 ----
W, H = 48, 60                 # 基础帧尺寸（与 sprites.py 一致）
MIN_SCALE, MAX_SCALE = 1, 8   # 大小范围
DEFAULT_SCALE = 3             # 默认大小
DEFAULT_CLICK_THROUGH = True  # 默认穿透（不挡点击）
FOLLOW_GAP = (30, 6)          # 宠物左下角相对鼠标：右 30px、上 6px
SPRING_K = 0.12               # 跟随弹簧系数
DAMPING = 0.82                # 阻尼
TICK_MS = 16                  # 主循环周期
IDLE_MS = 260                 # 待机每帧时长
FLY_MS = 90                   # 飞行每帧时长
TAP_MS = 70                   # 挥剑每帧时长
IDLE_SPEED = 2.5              # 光标每帧位移低于此值视为静止

VK_LBUTTON = 0x01
VK_CONTROL = 0x11
VK_MENU = 0x12          # Alt
VK_P = 0x50
VK_T = 0x54
VK_Q = 0x51

# 窗口样式 / 点击穿透
GWL_EXSTYLE = -20
WS_EX_TRANSPARENT = 0x20
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_NOZORDER = 0x0004
SWP_NOACTIVATE = 0x0010
SWP_FRAMECHANGED = 0x0020

SM_XVIRTUALSCREEN, SM_YVIRTUALSCREEN = 76, 77
SM_CXVIRTUALSCREEN, SM_CYVIRTUALSCREEN = 78, 79

user32 = ctypes.windll.user32

# ---- 低级鼠标钩子（仅作增强；点击检测以 GetAsyncKeyState 轮询为主）----
WH_MOUSE_LL = 14
WM_LBUTTONDOWN = 0x0201


class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("pt", wintypes.POINT),
                ("mouseData", wintypes.DWORD),
                ("flags", wintypes.DWORD),
                ("time", wintypes.DWORD),
                ("dwExtraInfo", ctypes.c_void_p)]


LowLevelMouseProc = ctypes.WINFUNCTYPE(
    ctypes.c_ssize_t,           # LRESULT
    ctypes.c_int,               # int nCode
    ctypes.c_size_t,            # WPARAM (UINT_PTR)
    ctypes.c_void_p)            # LPARAM (指针)

user32.SetWindowsHookExW.restype = ctypes.c_void_p
user32.SetWindowsHookExW.argtypes = [ctypes.c_int, ctypes.c_void_p,
                                     ctypes.c_void_p, wintypes.DWORD]
user32.CallNextHookEx.restype = ctypes.c_ssize_t
user32.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                  ctypes.c_size_t, ctypes.c_void_p]
user32.UnhookWindowsHookEx.restype = wintypes.BOOL
user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]

user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
user32.GetWindowLongPtrW.argtypes = [ctypes.c_void_p, ctypes.c_int]
user32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
user32.SetWindowLongPtrW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_ssize_t]
user32.SetWindowPos.restype = wintypes.BOOL
user32.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int,
                                ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
user32.GetParent.restype = ctypes.c_void_p
user32.GetParent.argtypes = [ctypes.c_void_p]

_G_APP = None


@LowLevelMouseProc
def _mouse_proc(nCode, wParam, lParam):
    try:
        if nCode >= 0 and wParam == WM_LBUTTONDOWN and _G_APP is not None:
            if lParam:
                ms = ctypes.cast(lParam, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
                _G_APP.on_global_click(ms.pt.x, ms.pt.y)
    except Exception:
        pass
    return user32.CallNextHookEx(None, nCode, wParam, lParam)


def cursor_pos():
    pt = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(pt))
    return float(pt.x), float(pt.y)


def virtual_screen():
    return (user32.GetSystemMetrics(SM_XVIRTUALSCREEN),
            user32.GetSystemMetrics(SM_YVIRTUALSCREEN),
            user32.GetSystemMetrics(SM_CXVIRTUALSCREEN),
            user32.GetSystemMetrics(SM_CYVIRTUALSCREEN))


def key_down(vk):
    return bool(user32.GetAsyncKeyState(vk) & 0x8000)


class PetApp:
    def __init__(self, smoke=False):
        global _G_APP
        self.smoke = smoke
        self.follow = True
        self.saved_pos = None
        self.scale = DEFAULT_SCALE
        self.click_through = DEFAULT_CLICK_THROUGH
        self.load_config()

        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.attributes("-transparentcolor", "#ff00ff")
        self.root.config(bg="#ff00ff")

        self.scale_var = tk.IntVar(value=self.scale)

        self.base_frames = self.load_base_frames()
        self.rebuild_frames()

        self.label = tk.Label(self.root, bd=0, highlightthickness=0, bg="#ff00ff")
        self.label.pack()
        self.label.bind("<Button-1>", self.on_press)
        self.label.bind("<B1-Motion>", self.on_motion)
        self.label.bind("<ButtonRelease-1>", self.on_release)
        self.label.bind("<Button-3>", self.on_right)
        self.label.bind("<MouseWheel>", self.on_wheel)

        # 初始位置
        cx, cy = cursor_pos()
        if not self.follow and self.saved_pos and self.saved_pos[0] is not None:
            self.pos = [float(self.saved_pos[0]), float(self.saved_pos[1])]
        else:
            self.pos = [cx + FOLLOW_GAP[0], cy - FOLLOW_GAP[1] - self.win_h]
        self.vx = self.vy = 0.0
        self.last_cx, self.last_cy = cx, cy
        self.cursor_speed = 0.0

        # 动画状态
        self.state = "idle"
        self.frame_index = 0
        self.frame_timer = 0

        # 输入状态
        self.left_was_down = False
        self.ctrl_held = False
        self._hotkey_fired = False
        self.dragging = False
        self.drag_moved = False
        self.drag_dx = self.drag_dy = 0
        self.hidden = False

        # 鼠标钩子仅作增强（可能被安全软件拦截）；点击检测以轮询为主
        _G_APP = self
        try:
            self.hook = user32.SetWindowsHookExW(WH_MOUSE_LL, _mouse_proc, None, 0)
        except Exception:
            self.hook = None
        if not self.hook:
            self.hook = None

        self._last_drawn = None
        self.render()
        # 窗口要等 mainloop 映射后才有顶层父窗口，延迟应用穿透状态
        self.root.after(100, self.apply_click_through)

    # ---- 资源 ----
    def load_base_frames(self):
        base = {}
        for name, count in (("idle", 2), ("fly", 2), ("tap", 4)):
            lst = []
            for i in range(count):
                path = os.path.join(ASSET_DIR, f"{name}_{i}.png")
                if not os.path.exists(path):
                    print("缺少素材文件：", path)
                    print("请先运行 python sprites.py 生成帧图。")
                    sys.exit(1)
                lst.append(tk.PhotoImage(file=path))
            base[name] = lst
        return base

    def rebuild_frames(self):
        self.win_w = W * self.scale
        self.win_h = H * self.scale
        if self.scale == 1:
            self.frames = {k: list(v) for k, v in self.base_frames.items()}
        else:
            self.frames = {k: [im.zoom(self.scale, self.scale) for im in v]
                           for k, v in self.base_frames.items()}

    # ---- 配置 ----
    def load_config(self):
        try:
            if os.path.exists(CONFIG_PATH):
                with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                    c = json.load(f)
                self.follow = bool(c.get("follow", True))
                x, y = c.get("x"), c.get("y")
                self.saved_pos = (x, y) if (x is not None and y is not None) else None
                self.scale = max(MIN_SCALE, min(MAX_SCALE, int(c.get("scale", DEFAULT_SCALE))))
                self.click_through = bool(c.get("click_through", DEFAULT_CLICK_THROUGH))
        except Exception:
            self.follow, self.saved_pos, self.scale = True, None, DEFAULT_SCALE
            self.click_through = DEFAULT_CLICK_THROUGH

    def save_config(self):
        try:
            with open(CONFIG_PATH, "w", encoding="utf-8") as f:
                json.dump({"follow": self.follow,
                           "x": int(self.pos[0]), "y": int(self.pos[1]),
                           "scale": self.scale,
                           "click_through": self.click_through}, f)
        except Exception:
            pass

    # ---- 交互 ----
    def on_press(self, e):
        self.dragging = True
        self.drag_moved = False
        cx, cy = cursor_pos()
        self.drag_dx = cx - self.pos[0]
        self.drag_dy = cy - self.pos[1]

    def on_motion(self, e):
        if not self.dragging:
            return
        cx, cy = cursor_pos()
        nx, ny = cx - self.drag_dx, cy - self.drag_dy
        if abs(nx - self.pos[0]) + abs(ny - self.pos[1]) > 3:
            self.drag_moved = True
        self.pos = [nx, ny]
        self.follow = False
        self.move_window()

    def on_release(self, e):
        was_drag = self.drag_moved
        self.dragging = False
        self.drag_moved = False
        if was_drag:
            self.follow = False
            self.save_config()
        else:
            self.trigger_tap()   # 单击宠物 = 抚摸，挥剑

    def on_global_click(self, x, y):
        """全局点击（来自鼠标钩子）。点击落在宠物窗口内则交给 tkinter 处理。"""
        if self.dragging:
            return
        px, py = self.pos
        if px <= x <= px + self.win_w and py <= y <= py + self.win_h:
            return
        self.trigger_tap()

    def on_wheel(self, e):
        self.set_scale(self.scale + (1 if e.delta > 0 else -1))

    def on_right(self, e):
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="跟随鼠标" + ("" if not self.follow else " ✓"),
                         command=self.set_follow)
        menu.add_command(label="固定在这里" + ("" if self.follow else " ✓"),
                         command=self.set_pin)
        menu.add_separator()

        size_menu = tk.Menu(menu, tearoff=0)
        for s in range(MIN_SCALE, MAX_SCALE + 1):
            size_menu.add_radiobutton(label=f"{s}×", value=s,
                                      variable=self.scale_var,
                                      command=lambda s=s: self.set_scale(s))
        menu.add_cascade(label="大小  (滚轮也可以调)", menu=size_menu)

        menu.add_separator()
        menu.add_command(label="鼠标穿透（点不到我）" + ("" if not self.click_through else " ✓"),
                         command=self.toggle_click_through)
        menu.add_command(label="按住 Ctrl 可临时抓取/控制宠物", state="disabled")
        menu.add_command(label="隐藏  (Ctrl+Alt+P)", command=self.toggle_hidden)
        menu.add_separator()
        menu.add_command(label="退出  (Ctrl+Alt+Q)", command=self.quit)
        try:
            menu.tk_popup(e.x_root, e.y_root)
        finally:
            menu.grab_release()

    def set_follow(self):
        self.follow = True
        self.save_config()

    def set_pin(self):
        self.follow = False
        self.save_config()

    def set_scale(self, s):
        s = max(MIN_SCALE, min(MAX_SCALE, int(s)))
        if s == self.scale:
            return
        self.scale = s
        self.scale_var.set(s)
        self.rebuild_frames()
        self._last_drawn = None
        self.root.geometry("%dx%d+%d+%d" % (self.win_w, self.win_h,
                                            int(self.pos[0]), int(self.pos[1])))
        self.render()
        self.save_config()

    def _effective_click_through(self):
        """实际是否穿透：用户设置了穿透，且没有按住 Ctrl（按住 Ctrl 时临时可点）。"""
        return self.click_through and not self.ctrl_held

    def apply_click_through(self):
        """让整只宠物穿透鼠标点击（点不到），或恢复可点击。"""
        try:
            # 真正的顶层窗口是 TkChild 的父窗口（TkTopLevel）；
            # winfo_id() 返回的是子窗口，改它没有用。
            hwnd = user32.GetParent(self.root.winfo_id())
            if not hwnd:
                return
            style = user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE)
            if self._effective_click_through():
                style |= WS_EX_TRANSPARENT
            else:
                style &= ~WS_EX_TRANSPARENT
            user32.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, style)
            user32.SetWindowPos(hwnd, None, 0, 0, 0, 0,
                                SWP_NOSIZE | SWP_NOMOVE | SWP_NOZORDER |
                                SWP_NOACTIVATE | SWP_FRAMECHANGED)
        except Exception:
            pass

    def toggle_click_through(self):
        self.click_through = not self.click_through
        self.apply_click_through()
        self.save_config()

    def _poll_keys(self):
        """用 GetAsyncKeyState 轮询 Ctrl 与热键（不依赖钩子，安全软件拦不住）。"""
        ctrl = key_down(VK_CONTROL)
        if ctrl != self.ctrl_held:
            self.ctrl_held = ctrl
            self.apply_click_through()   # Ctrl 按住→临时可点；松开→恢复穿透

        alt = key_down(VK_MENU)
        if ctrl and alt and not self._hotkey_fired:
            if key_down(VK_P):
                self._hotkey_fired = True
                self.toggle_hidden()
            elif key_down(VK_T):
                self._hotkey_fired = True
                self.toggle_click_through()
            elif key_down(VK_Q):
                self._hotkey_fired = True
                self.quit()
        if not (ctrl and alt):
            self._hotkey_fired = False

    def toggle_hidden(self):
        self.hidden = not self.hidden
        if self.hidden:
            self.root.withdraw()
        else:
            self.root.deiconify()
            self.root.attributes("-topmost", True)

    def quit(self):
        global _G_APP
        _G_APP = None
        try:
            if self.hook:
                user32.UnhookWindowsHookEx(self.hook)
                self.hook = None
            self.save_config()
        finally:
            self.root.destroy()

    # ---- 动画 ----
    def trigger_tap(self):
        if self.state != "tap":
            self.state = "tap"
            self.frame_index = 0
            self.frame_timer = 0

    def update_animation(self, moving):
        if self.state == "tap":
            self.frame_timer += TICK_MS
            idx = self.frame_timer // TAP_MS
            if idx >= len(self.frames["tap"]):
                self.state = "idle"
                self.frame_index = 0
                self.frame_timer = 0
            else:
                self.frame_index = idx
            return

        anim = "fly" if moving else "idle"
        if anim != self.state:
            self.state = anim
            self.frame_index = 0
            self.frame_timer = 0
        per = FLY_MS if anim == "fly" else IDLE_MS
        self.frame_timer += TICK_MS
        if self.frame_timer >= per:
            self.frame_timer -= per
            self.frame_index = (self.frame_index + 1) % len(self.frames[anim])

    # ---- 物理 ----
    def update_physics(self, cx, cy):
        # 按住 Ctrl 时停住跟随（方便抓住宠物），否则跟随/固定
        if self.follow and not self.dragging and not self.ctrl_held:
            tx = cx + FOLLOW_GAP[0]
            ty = cy - FOLLOW_GAP[1] - self.win_h
        else:
            tx, ty = self.pos[0], self.pos[1]
        self.vx = (self.vx + (tx - self.pos[0]) * SPRING_K) * DAMPING
        self.vy = (self.vy + (ty - self.pos[1]) * SPRING_K) * DAMPING
        self.pos[0] += self.vx
        self.pos[1] += self.vy
        vl, vt, vw, vh = virtual_screen()
        self.pos[0] = min(max(self.pos[0], vl), vl + vw - self.win_w)
        self.pos[1] = min(max(self.pos[1], vt), vt + vh - self.win_h)

    # ---- 渲染 ----
    def move_window(self):
        key = (int(self.pos[0]), int(self.pos[1]))
        if key != self._last_drawn:
            self.root.geometry("+%d+%d" % key)
            self._last_drawn = key

    def render(self):
        self.label.config(image=self.frames[self.state][self.frame_index])
        self.move_window()

    # ---- 主循环 ----
    def step(self):
        cx, cy = cursor_pos()

        d = math.hypot(cx - self.last_cx, cy - self.last_cy)
        self.last_cx, self.last_cy = cx, cy
        self.cursor_speed = self.cursor_speed * 0.85 + d * 0.15
        # 关键修复：只有“跟随模式”下光标移动才算“飞”，固定后不飞
        moving = self.follow and not self.ctrl_held and self.cursor_speed > IDLE_SPEED

        # 点击：GetAsyncKeyState 轮询为主（鼠标钩子仅作增强，可能被安全软件拦截）
        pressed = key_down(VK_LBUTTON)
        if pressed and not self.left_was_down and not self.dragging:
            # 点击落在宠物窗口内交给 tkinter（拖拽/右键/抚摸），否则全局挥剑
            if not (self.pos[0] <= cx <= self.pos[0] + self.win_w and
                    self.pos[1] <= cy <= self.pos[1] + self.win_h):
                self.trigger_tap()
        self.left_was_down = pressed

        # Ctrl 状态 + 热键：轮询
        self._poll_keys()

        self.update_physics(cx, cy)
        self.update_animation(moving)
        self.render()

    def loop(self):
        self.step()
        self.root.after(TICK_MS, self.loop)


def _show_test(transparent):
    root = tk.Tk()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    if transparent:
        root.attributes("-transparentcolor", "#ff00ff")
        bg = "#ff00ff"
    else:
        bg = "#204060"   # 不透明深蓝底，便于看清
    root.config(bg=bg)
    img = tk.PhotoImage(file=os.path.join(ASSET_DIR, "idle_0.png")).zoom(3, 3)
    tk.Label(root, image=img, bd=0, highlightthickness=0, bg=bg).pack()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    x = max(0, (sw - img.width()) // 2)
    y = max(0, (sh - img.height()) // 2)
    root.geometry("%dx%d+%d+%d" % (img.width(), img.height(), x, y))
    root.update()
    hwnd = user32.GetParent(root.winfo_id())
    ex0 = user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE)
    user32.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, ex0 | WS_EX_TRANSPARENT)
    ex1 = user32.GetWindowLongPtrW(hwnd, GWL_EXSTYLE)
    user32.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, ex0)
    print("[%s] geometry=%s mapped=%s" %
          ("transparent" if transparent else "solid",
           root.geometry(), bool(root.winfo_ismapped())))
    print("[hwnd=%s] click-through style toggle: ok=%s" %
          (hwnd, bool(ex1 & WS_EX_TRANSPARENT) and not bool(ex0 & WS_EX_TRANSPARENT)))
    root.after(2500, root.destroy)
    root.mainloop()


def check_mode():
    """诊断模式：打印环境信息，并两次显示窗口帮助定位问题。"""
    print("== PET DIAGNOSTIC ==")
    print("Python:", sys.version.split()[0])
    print("Tk:", tk.TkVersion)
    print("Virtual screen:", virtual_screen())
    print("Cursor:", cursor_pos())

    missing = []
    for name, count in (("idle", 2), ("fly", 2), ("tap", 4)):
        for i in range(count):
            p = os.path.join(ASSET_DIR, f"{name}_{i}.png")
            if not os.path.exists(p):
                missing.append(p)
    print("Missing frames:", missing if missing else "none")
    if missing:
        print("Run: python sprites.py")
        return

    print("-- test 1: TRANSPARENT pet at screen center (2.5s) --")
    _show_test(True)
    print("-- test 2: SOLID background pet at screen center (2.5s) --")
    _show_test(False)
    print("== DONE ==")


def main():
    if "--check" in sys.argv:
        check_mode()
        return
    smoke = "--smoke-test" in sys.argv
    app = PetApp(smoke=smoke)
    if smoke:
        for _ in range(8):
            app.step()
            app.root.update()
        app.quit()
        print("SMOKE OK")
        return
    app.root.after(0, app.loop)
    app.root.mainloop()


if __name__ == "__main__":
    main()

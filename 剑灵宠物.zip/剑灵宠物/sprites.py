# -*- coding: utf-8 -*-
"""
生成像素风「小剑灵」宠物帧图。

用法:
    python sprites.py            # 生成 assets/*.png 和 preview.png
    python sprites.py --preview  # 仅生成一张拼图预览 preview.png

生成的 PNG 以品红 (#FF00FF) 为背景，主程序用 -transparentcolor 抠掉，
所以背景色一定不要和角色本身颜色冲突。
"""
import os
from PIL import Image, ImageDraw

# 品红 = 透明色（抠图用）
MAGENTA = (255, 0, 255, 255)

# 调色板
OUTLINE  = (58, 62, 86, 255)      # 描边
BODY     = (246, 249, 255, 255)   # 身体主色（冷白）
BODY_SH  = (196, 214, 242, 255)   # 身体阴影（淡蓝）
BELLY    = (226, 234, 250, 255)   # 肚皮
EYE      = (48, 52, 74, 255)      # 眼睛
EYE_HI   = (255, 255, 255, 255)   # 眼睛高光
BLUSH    = (255, 168, 182, 255)   # 腮红
BLADE    = (182, 226, 242, 255)   # 剑身
BLADE_HI = (236, 251, 255, 255)   # 剑身高光
GUARD    = (240, 192, 82, 255)    # 剑格（金）
HILT     = (96, 70, 46, 255)      # 剑柄（棕）
GLOW     = (172, 220, 250, 255)   # 光晕
SPARK    = (255, 244, 200, 255)   # 挥剑火花

W, H = 48, 60
ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")

# 全部实际用到的颜色（用于把抗锯齿杂色像素归一到最近色，保证抠图无粉边）
PALETTE = [MAGENTA, OUTLINE, BODY, BODY_SH, BELLY, EYE, EYE_HI,
           BLUSH, BLADE, BLADE_HI, GUARD, HILT, GLOW, SPARK]


def snap_to_palette(img):
    """把每个像素映射到最近调色板色，消除 ImageDraw 抗锯齿产生的中间色。"""
    px = img.load()
    for y in range(img.height):
        for x in range(img.width):
            r, g, b, a = px[x, y]
            if a == 0:
                px[x, y] = MAGENTA
                continue
            best, bd = MAGENTA, 1 << 30
            for (pr, pg, pb, _) in PALETTE:
                d = (r - pr) ** 2 + (g - pg) ** 2 + (b - pb) ** 2
                if d < bd:
                    bd, best = d, (pr, pg, pb, 255)
            px[x, y] = best
    return img


def new_canvas():
    img = Image.new("RGBA", (W, H), MAGENTA)
    return img, ImageDraw.Draw(img)


def _line(d, p0, p1, color, width):
    d.line([p0, p1], fill=color, width=width, joint="curve")


def draw_sword(d, px, py, angle_deg, length=19):
    """以 (px,py) 为剑柄支点画一把剑。angle_deg: 0=竖直向上, 正=向右转。"""
    import math
    a = math.radians(angle_deg)
    dx, dy = math.sin(a), -math.cos(a)          # 剑尖方向
    # 剑柄（支点下方）
    _line(d, (px, py), (px + dx * -3, py - dy * -3 + 4), HILT, 3)
    # 剑格（横向小横条）
    gx, gy = -dy, dx
    _line(d, (px - gx * 3, py - gy * 3), (px + gx * 3, py + gy * 3), GUARD, 3)
    # 剑身
    tip = (px + dx * length, py + dy * length)
    _line(d, (px, py), tip, BLADE, 4)
    _line(d, (px + dx * 2, py + dy * 2), (tip[0] - dx * 2, tip[1] - dy * 2), BLADE_HI, 2)


def draw_body(d, ox=0, oy=0, lean=0, arms="rest", squash=0):
    """画小剑灵本体（幽灵状圆润身体 + 眼睛 + 腮红 + 小手臂）。
    ox/oy: 整体平移; lean: 身体水平倾斜(像素); arms: rest|up|back|down."""
    # 身体轮廓（先画深色描边，再画浅色主体，形成 1px 描边）
    cx = 24 + ox
    # 头部圆顶
    d.ellipse([8 + ox, 22 + oy, 40 + ox, 52 + oy], fill=OUTLINE)
    # 底部波浪（幽灵裙摆）
    d.rectangle([8 + ox, 34 + oy, 40 + ox, 50 + oy], fill=OUTLINE)
    d.ellipse([6 + ox, 44 + oy, 18 + ox, 54 + oy], fill=OUTLINE)
    d.ellipse([16 + ox, 44 + oy, 32 + ox, 55 + oy], fill=OUTLINE)
    d.ellipse([30 + ox, 44 + oy, 42 + ox, 54 + oy], fill=OUTLINE)

    # 主体（内缩 1px）
    d.ellipse([9 + ox, 23 + oy, 39 + ox, 51 + oy], fill=BODY)
    d.rectangle([9 + ox, 34 + oy, 39 + ox, 49 + oy], fill=BODY)
    d.ellipse([8 + ox, 45 + oy, 19 + ox, 53 + oy], fill=BODY)
    d.ellipse([17 + ox, 45 + oy, 31 + ox, 54 + oy], fill=BODY)
    d.ellipse([29 + ox, 45 + oy, 40 + ox, 53 + oy], fill=BODY)

    # 阴影（左侧淡蓝，给体积感）
    d.ellipse([12 + ox, 27 + oy, 20 + ox, 48 + oy], fill=BODY_SH)

    # 肚皮
    d.ellipse([15 + ox, 38 + oy, 33 + ox, 52 + oy], fill=BELLY)

    # 眼睛（两个大圆 + 左上高光 + 右下小高光）
    for ex in (16, 30):
        d.ellipse([ex - 4 + ox, 32 + oy, ex + 4 + ox, 41 + oy], fill=EYE)
        d.ellipse([ex - 3 + ox, 33 + oy, ex + ox, 36 + oy], fill=EYE_HI)
        d.ellipse([ex + 1 + ox, 38 + oy, ex + 3 + ox, 40 + oy], fill=EYE_HI)

    # 腮红
    d.ellipse([11 + ox, 41 + oy, 16 + ox, 44 + oy], fill=BLUSH)
    d.ellipse([32 + ox, 41 + oy, 37 + ox, 44 + oy], fill=BLUSH)

    # 手臂
    if arms == "rest":
        d.ellipse([6 + ox, 38 + oy, 12 + ox, 45 + oy], fill=OUTLINE)
        d.ellipse([7 + ox, 39 + oy, 11 + ox, 44 + oy], fill=BODY)
        d.ellipse([36 + ox, 38 + oy, 42 + ox, 45 + oy], fill=OUTLINE)
        d.ellipse([37 + ox, 39 + oy, 41 + ox, 44 + oy], fill=BODY)
    elif arms == "up":
        d.ellipse([5 + ox, 30 + oy, 11 + ox, 37 + oy], fill=OUTLINE)
        d.ellipse([6 + ox, 31 + oy, 10 + ox, 36 + oy], fill=BODY)
        d.ellipse([37 + ox, 30 + oy, 43 + ox, 37 + oy], fill=OUTLINE)
        d.ellipse([38 + ox, 31 + oy, 42 + ox, 36 + oy], fill=BODY)
    elif arms == "down":
        d.ellipse([6 + ox, 42 + oy, 12 + ox, 49 + oy], fill=OUTLINE)
        d.ellipse([7 + ox, 43 + oy, 11 + ox, 48 + oy], fill=BODY)
        d.ellipse([36 + ox, 42 + oy, 42 + ox, 49 + oy], fill=OUTLINE)
        d.ellipse([37 + ox, 43 + oy, 41 + ox, 48 + oy], fill=BODY)
    else:  # back（飞行，向后摆）
        d.ellipse([4 + ox, 40 + oy, 10 + ox, 47 + oy], fill=OUTLINE)
        d.ellipse([5 + ox, 41 + oy, 9 + ox, 46 + oy], fill=BODY)
        d.ellipse([38 + ox, 36 + oy, 44 + ox, 43 + oy], fill=OUTLINE)
        d.ellipse([39 + ox, 37 + oy, 43 + ox, 42 + oy], fill=BODY)


def slash_effect(d, cx, cy):
    """挥剑的半月形剑气弧线。"""
    d.arc([cx - 22, cy - 16, cx + 22, cy + 16], start=200, end=330, fill=BLADE_HI, width=2)
    d.arc([cx - 18, cy - 12, cx + 18, cy + 12], start=210, end=320, fill=GLOW, width=2)


def frame_idle_0():
    img, d = new_canvas()
    draw_body(d, oy=0, arms="rest")
    draw_sword(d, 39, 33, -28)
    return img


def frame_idle_1():
    img, d = new_canvas()
    draw_body(d, oy=-2, arms="rest")
    draw_sword(d, 39, 31, -28)
    return img


def frame_fly_0():
    img, d = new_canvas()
    draw_body(d, ox=2, oy=0, arms="back")
    draw_sword(d, 41, 32, -60)
    # 速度线
    _line(d, (2, 30), (8, 30), GLOW, 2)
    _line(d, (3, 40), (7, 40), GLOW, 2)
    return img


def frame_fly_1():
    img, d = new_canvas()
    draw_body(d, ox=1, oy=-1, arms="back")
    draw_sword(d, 40, 31, -52)
    _line(d, (3, 34), (9, 34), GLOW, 2)
    _line(d, (4, 44), (8, 44), GLOW, 2)
    return img


def frame_tap_0():
    img, d = new_canvas()
    draw_body(d, ox=-1, oy=0, arms="up")
    draw_sword(d, 40, 30, -70)
    return img


def frame_tap_1():
    img, d = new_canvas()
    draw_body(d, ox=2, oy=1, arms="down")
    draw_sword(d, 41, 36, 40)
    slash_effect(d, 24, 40)
    return img


def frame_tap_2():
    img, d = new_canvas()
    draw_body(d, ox=3, oy=2, arms="down")
    draw_sword(d, 42, 38, 70)
    slash_effect(d, 26, 42)
    return img


def frame_tap_3():
    img, d = new_canvas()
    draw_body(d, ox=0, oy=-1, arms="rest")
    draw_sword(d, 39, 32, -28)
    return img


FRAMES = {
    "idle": [frame_idle_0, frame_idle_1],
    "fly":  [frame_fly_0, frame_fly_1],
    "tap":  [frame_tap_0, frame_tap_1, frame_tap_2, frame_tap_3],
}


def generate():
    os.makedirs(ASSETS, exist_ok=True)
    for name, funcs in FRAMES.items():
        for i, fn in enumerate(funcs):
            img = snap_to_palette(fn())
            p = os.path.join(ASSETS, f"{name}_{i}.png")
            img.save(p)
            print("wrote", p)
    print("done")


def preview():
    imgs = []
    for name, funcs in FRAMES.items():
        for i, fn in enumerate(funcs):
            imgs.append(snap_to_palette(fn()))
    cols = len(imgs)
    sheet = Image.new("RGBA", (W * cols, H + 20), (40, 40, 50, 255))
    for i, img in enumerate(imgs):
        sheet.paste(img, (W * i, 20))
    sheet.save(os.path.join(ASSETS, "preview.png"))
    print("wrote", os.path.join(ASSETS, "preview.png"))


if __name__ == "__main__":
    import sys
    generate()
    preview()
